static int dissect_tsdns(tvbuff_t *tvb, packet_info *pinfo, proto_tree *tree, void* data _U_)
{

  int         offset    = 0;
  gboolean    request   = FALSE;

  if (pinfo->destport == pinfo->match_uint) {
    request = TRUE;
  }

  col_set_str(pinfo->cinfo, COL_PROTOCOL, "TSDNS");

  int pLen = tvb_reported_length(tvb);

  if (request) {
    col_set_str(pinfo->cinfo, COL_INFO, "Request");
    col_append_fstr(pinfo->cinfo, COL_INFO, " %.*s", pLen - 5, tvb_get_string_enc(wmem_packet_scope(), tvb, 0, pLen - 5, ENC_ASCII|ENC_NA));
  } else {
    col_set_str(pinfo->cinfo, COL_INFO, "Response");
    col_append_fstr(pinfo->cinfo, COL_INFO, " %.*s", pLen, tvb_get_string_enc(wmem_packet_scope(), tvb, 0, pLen, ENC_ASCII|ENC_NA));
  }

  proto_tree *tsdns_tree;
  proto_item *ti, *hidden_item, *address_item;

  ti = proto_tree_add_item(tree, proto_tsdns, tvb, offset, -1, ENC_NA);
  tsdns_tree = proto_item_add_subtree(ti, ett_tsdns);

  hidden_item = proto_tree_add_item(tsdns_tree, hf_tsdns_data, tvb, offset, -1, ENC_ASCII|ENC_NA);
  PROTO_ITEM_SET_HIDDEN(hidden_item);

  if (request) { // request is DOMAIN\n\r\r\r\n
    hidden_item = proto_tree_add_boolean(tsdns_tree, hf_tsdns_request, tvb, 0, 0, 1); // using pLen - 5 as the last chars are \n\r\r\r\n which are just indicating the end of the request
    proto_tree_add_item(tsdns_tree, hf_tsdns_request_domain, tvb, offset, pLen - 5, ENC_ASCII|ENC_NA);
  } else { // response is IP:PORT
    hidden_item = proto_tree_add_boolean(tsdns_tree, hf_tsdns_response, tvb, 0, 0, 1);
    address_item = proto_tree_add_item(tsdns_tree, hf_tsdns_response_address, tvb, offset, pLen, ENC_ASCII|ENC_NA);
    gchar** splitAddress;
    splitAddress = wmem_strsplit(wmem_packet_scope(), tvb_format_text(tvb, 0, pLen), ":", 1); // unsure if TSDNS also does IPv6...
    if (splitAddress[1] == NULL) {
      expert_add_info(pinfo, address_item, &ei_response_port_malformed);
    } else {
      proto_tree_add_string(tsdns_tree, hf_tsdns_response_ip, tvb, 0, pLen, splitAddress[0]);
      guint32 port;
      if (ws_strtou32(splitAddress[1], NULL, &port))
        proto_tree_add_uint(tsdns_tree, hf_tsdns_response_port, tvb, 0, pLen, port);
    }
  }
  PROTO_ITEM_SET_HIDDEN(hidden_item);

  return tvb_captured_length(tvb);

}
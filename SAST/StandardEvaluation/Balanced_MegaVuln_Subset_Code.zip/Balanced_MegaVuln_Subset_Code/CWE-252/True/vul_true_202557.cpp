static int
dissect_coap(tvbuff_t *tvb, packet_info *pinfo, proto_tree *parent_tree, void* data _U_)
{
	gint              offset = 0;
	proto_item       *coap_root;
	proto_item       *pi;
	proto_tree       *coap_tree;
	guint8            ttype;
	guint8            token_len;
	guint8            code;
	guint8            code_class;
	guint16           mid;
	gint              coap_length;
	gchar            *coap_token_str;
	coap_info        *coinfo;
	conversation_t   *conversation;
	coap_conv_info   *ccinfo;
	coap_transaction *coap_trans = NULL;

	/* Allocate information for upper layers */
	if (!PINFO_FD_VISITED(pinfo)) {
		coinfo = wmem_new0(wmem_file_scope(), coap_info);
		p_add_proto_data(wmem_file_scope(), pinfo, proto_coap, 0, coinfo);
	} else {
		coinfo = (coap_info *)p_get_proto_data(wmem_file_scope(), pinfo, proto_coap, 0);
	}

	/* initialize the CoAP length and the content-Format */
	/*
	 * the length of CoAP message is not specified in the CoAP header.
	 * It has to be from the lower layer.
	 * Currently, the length is just copied from the reported length of the tvbuffer.
	 */
	coap_length = tvb_reported_length(tvb);
	coinfo->ctype_str = "";
	coinfo->ctype_value = DEFAULT_COAP_CTYPE_VALUE;

	col_set_str(pinfo->cinfo, COL_PROTOCOL, "CoAP");
	col_clear(pinfo->cinfo, COL_INFO);

	coap_root = proto_tree_add_item(parent_tree, proto_coap, tvb, offset, -1, ENC_NA);
	coap_tree = proto_item_add_subtree(coap_root, ett_coap);

	proto_tree_add_item(coap_tree, hf_coap_version, tvb, offset, 1, ENC_BIG_ENDIAN);

	proto_tree_add_item(coap_tree, hf_coap_ttype, tvb, offset, 1, ENC_BIG_ENDIAN);
	ttype = (tvb_get_guint8(tvb, offset) & 0x30) >> 4;

	proto_tree_add_item(coap_tree, hf_coap_token_len, tvb, offset, 1, ENC_BIG_ENDIAN);
	token_len = tvb_get_guint8(tvb, offset) & 0x0f;

	offset += 1;

	proto_tree_add_item(coap_tree, hf_coap_code, tvb, offset, 1, ENC_BIG_ENDIAN);
	code = tvb_get_guint8(tvb, offset);
	code_class = code >> 5;
	offset += 1;

	proto_tree_add_item(coap_tree, hf_coap_mid, tvb, offset, 2, ENC_BIG_ENDIAN);
	mid = tvb_get_ntohs(tvb, offset);

	col_add_fstr(pinfo->cinfo, COL_INFO,
		     "%s, MID:%u, %s",
		     val_to_str(ttype, vals_ttype_short, "Unknown %u"),
		     mid,
		     val_to_str_ext(code, &vals_code_ext, "Unknown %u"));

	/* append the header information */
	proto_item_append_text(coap_root,
			       ", %s, %s, MID:%u",
			       val_to_str(ttype, vals_ttype, "Unknown %u"),
			       val_to_str_ext(code, &vals_code_ext, "Unknown %u"),
			       mid);

	offset += 2;

	/* initialize the external value */
	coinfo->block_number = DEFAULT_COAP_BLOCK_NUMBER;
	coinfo->block_mflag  = 0;
	coinfo->uri_str_strbuf   = wmem_strbuf_sized_new(wmem_packet_scope(), 0, 1024);
	coinfo->uri_query_strbuf = wmem_strbuf_sized_new(wmem_packet_scope(), 0, 1024);
	coap_token_str = NULL;
	if (token_len > 0)
	{
		/* This has to be file scope as the token string is stored in the map
		* for conversation lookup */
		coap_token_str = tvb_bytes_to_str_punct(wmem_file_scope(), tvb, offset, token_len, ' ');
		proto_tree_add_item(coap_tree, hf_coap_token,
				    tvb, offset, token_len, ENC_NA);
		offset += token_len;
	}

	/* process options */
	offset = dissect_coap_options(tvb, pinfo, coap_tree, offset, coap_length, coinfo);
	if (offset == -1)
		return tvb_captured_length(tvb);

	/* Use conversations to track state for request/response */
	conversation = find_or_create_conversation_noaddrb(pinfo, (code_class == 0));

	/* Retrieve or create state structure for this conversation */
	ccinfo = (coap_conv_info *)conversation_get_proto_data(conversation, proto_coap);
	if (!ccinfo) {
		/* No state structure - create it */
		ccinfo = wmem_new(wmem_file_scope(), coap_conv_info);
		ccinfo->messages = wmem_map_new(wmem_file_scope(), g_str_hash, g_str_equal);
		conversation_add_proto_data(conversation, proto_coap, ccinfo);
	}

	/* Everything based on tokens */
	if (coap_token_str != NULL) {
		/* Process request/response in conversation */
		if (code != 0) { /* Ignore empty messages */
			/* Try and look up a matching token. If it's the first
			* sight of a request, there shouldn't be one */
			coap_trans = (coap_transaction *)wmem_map_lookup(ccinfo->messages, coap_token_str);
			if (!coap_trans) {
				if ((!PINFO_FD_VISITED(pinfo)) && (code_class == 0)) {
					/* New request - log it */
					coap_trans = wmem_new(wmem_file_scope(), coap_transaction);
					coap_trans->req_frame = pinfo->num;
					coap_trans->rsp_frame = 0;
					coap_trans->req_time = pinfo->fd->abs_ts;
					if (coinfo->uri_str_strbuf) {
						/* Store the URI into CoAP transaction info */
						coap_trans->uri_str_strbuf = wmem_strbuf_new(wmem_file_scope(), wmem_strbuf_get_str(coinfo->uri_str_strbuf));
					}
					wmem_map_insert(ccinfo->messages, coap_token_str, (void *)coap_trans);
				}
			} else {
				if ((code_class >= 2) && (code_class <= 5)) {
					if (!PINFO_FD_VISITED(pinfo)) {
						/* Log the first matching response frame */
						coap_trans->rsp_frame = pinfo->num;
					}
					if (coap_trans->uri_str_strbuf) {
						/* Copy the URI stored in matching transaction info into CoAP packet info */
						coinfo->uri_str_strbuf = wmem_strbuf_new(wmem_packet_scope(), wmem_strbuf_get_str(coap_trans->uri_str_strbuf));
					}
				}
			}
		}
	}

	if (coap_trans != NULL) {
		/* Print state tracking in the tree */
		if (code_class == 0) {
			/* This is a request */
			if (coap_trans->rsp_frame) {
				proto_item *it;

				it = proto_tree_add_uint(coap_tree, hf_coap_response_in,
						tvb, 0, 0, coap_trans->rsp_frame);
				PROTO_ITEM_SET_GENERATED(it);
			}
		} else if ((code_class >= 2) && (code_class <= 5)) {
			/* This is a reply */
			if (coap_trans->req_frame) {
				proto_item *it;
				nstime_t ns;

				it = proto_tree_add_uint(coap_tree, hf_coap_response_to,
						tvb, 0, 0, coap_trans->req_frame);
				PROTO_ITEM_SET_GENERATED(it);

				nstime_delta(&ns, &pinfo->fd->abs_ts, &coap_trans->req_time);
				it = proto_tree_add_time(coap_tree, hf_coap_response_time, tvb, 0, 0, &ns);
				PROTO_ITEM_SET_GENERATED(it);
			}
		}
	}

	/* add informations to the packet list */
	if (coap_token_str != NULL)
		col_append_fstr(pinfo->cinfo, COL_INFO, ", TKN:%s", coap_token_str);
	if (coinfo->block_number != DEFAULT_COAP_BLOCK_NUMBER)
		col_append_fstr(pinfo->cinfo, COL_INFO, ", %sBlock #%u",
				coinfo->block_mflag ? "" : "End of ", coinfo->block_number);
	if (wmem_strbuf_get_len(coinfo->uri_str_strbuf) > 0) {
		col_append_fstr(pinfo->cinfo, COL_INFO, ", %s", wmem_strbuf_get_str(coinfo->uri_str_strbuf));
		/* Add to hidden protocol item as well */
		pi = proto_tree_add_string(coap_tree, hf_coap_opt_uri_path_recon, tvb, 0, 0, wmem_strbuf_get_str(coinfo->uri_str_strbuf));
		PROTO_ITEM_SET_HIDDEN(pi);
	}
	if (wmem_strbuf_get_len(coinfo->uri_query_strbuf)> 0)
		col_append_str(pinfo->cinfo, COL_INFO, wmem_strbuf_get_str(coinfo->uri_query_strbuf));

	/* dissect the payload */
	if (coap_length > offset) {
		proto_tree *payload_tree;
		proto_item *payload_item, *length_item;
		tvbuff_t   *payload_tvb;
		guint	    payload_length = coap_length - offset;
		const char *coap_ctype_str_dis;
		char	    str_payload[80];

		/* coinfo->ctype_value == DEFAULT_COAP_CTYPE_VALUE: No Content-Format option present */
		/* coinfo->ctype_value == 0: Content-Format option present with length 0 */
		if (coinfo->ctype_value == DEFAULT_COAP_CTYPE_VALUE || coinfo->ctype_value == 0) {
			/*
			* 5.5.2.  Diagnostic Payload
			*
			* If no Content-Format option is given, the payload of responses
			* indicating a client or server error is a brief human-readable
			* diagnostic message, explaining the error situation. This diagnostic
			* message MUST be encoded using UTF-8 [RFC3629], more specifically
			* using Net-Unicode form [RFC5198].
			*/
			if ((code_class >= 4) && (code_class <= 5)) {
				coinfo->ctype_str = "text/plain; charset=utf-8";
				coap_ctype_str_dis = "text/plain";
			} else {
				/* Assume no Content-Format is opaque octet stream */
				coinfo->ctype_str = "application/octet-stream";
				coap_ctype_str_dis = coinfo->ctype_str;
			}
		} else {
			coap_ctype_str_dis = coinfo->ctype_str;
		}

		g_snprintf(str_payload, sizeof(str_payload),
			"Payload Content-Format: %s%s, Length: %u",
			coinfo->ctype_str, coinfo->ctype_value == DEFAULT_COAP_CTYPE_VALUE ?
			" (no Content-Format)" : "", payload_length);

		payload_item = proto_tree_add_string(coap_tree, hf_coap_payload,
						     tvb, offset, payload_length,
						     str_payload);
		payload_tree = proto_item_add_subtree(payload_item, ett_coap_payload);

		proto_tree_add_string(payload_tree, hf_coap_payload_desc, tvb, offset, 0, coinfo->ctype_str);
		length_item = proto_tree_add_uint(payload_tree, hf_coap_payload_length, tvb, offset, 0, payload_length);
		PROTO_ITEM_SET_GENERATED(length_item);
		payload_tvb = tvb_new_subset_length(tvb, offset, payload_length);

		dissector_try_string(media_type_dissector_table, coap_ctype_str_dis,
				     payload_tvb, pinfo, parent_tree, NULL);
	}

	return tvb_captured_length(tvb);
}
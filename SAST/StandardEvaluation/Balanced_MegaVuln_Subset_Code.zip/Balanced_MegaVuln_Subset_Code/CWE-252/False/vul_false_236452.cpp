struct hashmap *ids__new(void)
{
	return hashmap__new(key_hash, key_equal, NULL);
}
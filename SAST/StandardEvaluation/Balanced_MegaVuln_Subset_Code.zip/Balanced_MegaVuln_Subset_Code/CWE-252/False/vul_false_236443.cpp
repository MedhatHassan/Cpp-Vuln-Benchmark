int expr__add_id_val(struct expr_parse_ctx *ctx, const char *id, double val)
{
	return expr__add_id_val_source_count(ctx, id, val, /*source_count=*/1);
}
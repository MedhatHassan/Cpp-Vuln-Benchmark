static bool kfd_ignore_crat(void)
{
	bool ret;

	if (ignore_crat)
		return true;

#ifndef KFD_SUPPORT_IOMMU_V2
	ret = true;
#else
	ret = false;
#endif

	return ret;
}
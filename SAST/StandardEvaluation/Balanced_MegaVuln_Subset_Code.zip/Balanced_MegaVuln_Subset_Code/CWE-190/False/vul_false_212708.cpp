SV*
Perl_get_c_backtrace_dump(pTHX_ int depth, int skip)
{
    Perl_c_backtrace* bt;

    bt = get_c_backtrace(depth, skip + 1 /* Hide ourselves. */);
    if (bt) {
        Perl_c_backtrace_frame* frame;
        SV* dsv = newSVpvs("");
        UV i;
        for (i = 0, frame = bt->frame_info;
             i < bt->header.frame_count; i++, frame++) {
            Perl_sv_catpvf(aTHX_ dsv, "%d", (int)i);
            Perl_sv_catpvf(aTHX_ dsv, "\t%p", frame->addr ? frame->addr : "-");
            /* Symbol (function) names might disappear without debug info.
             *
             * The source code location might disappear in case of the
             * optimizer inlining or otherwise rearranging the code. */
            if (frame->symbol_addr) {
                Perl_sv_catpvf(aTHX_ dsv, ":%04x",
                               (int)
                               ((char*)frame->addr - (char*)frame->symbol_addr));
            }
            Perl_sv_catpvf(aTHX_ dsv, "\t%s",
                           frame->symbol_name_size &&
                           frame->symbol_name_offset ?
                           (char*)bt + frame->symbol_name_offset : "-");
            if (frame->source_name_size &&
                frame->source_name_offset &&
                frame->source_line_number) {
                Perl_sv_catpvf(aTHX_ dsv, "\t%s:%" UVuf,
                               (char*)bt + frame->source_name_offset,
                               (UV)frame->source_line_number);
            } else {
                Perl_sv_catpvf(aTHX_ dsv, "\t-");
            }
            Perl_sv_catpvf(aTHX_ dsv, "\t%s",
                           frame->object_name_size &&
                           frame->object_name_offset ?
                           (char*)bt + frame->object_name_offset : "-");
            /* The frame->object_base_addr is not output,
             * but it is used for symbolizing/symbolicating. */
            sv_catpvs(dsv, "\n");
        }

        Perl_free_c_backtrace(bt);

        return dsv;
    }

    return NULL;
}
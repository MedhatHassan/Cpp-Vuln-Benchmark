static OPJ_BOOL opj_t1_allocate_buffers(
		opj_t1_t *t1,
		OPJ_UINT32 w,
		OPJ_UINT32 h)
{
	OPJ_UINT32 datasize=w * h;
	OPJ_UINT32 flagssize;

	/* encoder uses tile buffer, so no need to allocate */
	if (!t1->encoder) {
		if(datasize > t1->datasize){
			opj_aligned_free(t1->data);
			t1->data = (OPJ_INT32*) opj_aligned_malloc(datasize * sizeof(OPJ_INT32));
			if(!t1->data){
				/* FIXME event manager error callback */
				return OPJ_FALSE;
			}
			t1->datasize=datasize;
		}
		memset(t1->data,0,datasize * sizeof(OPJ_INT32));
	}
	t1->flags_stride=w+2;
	flagssize=t1->flags_stride * (h+2);

	if(flagssize > t1->flagssize){
		opj_aligned_free(t1->flags);
		t1->flags = (opj_flag_t*) opj_aligned_malloc(flagssize * sizeof(opj_flag_t));
		if(!t1->flags){
			/* FIXME event manager error callback */
			return OPJ_FALSE;
		}
		t1->flagssize=flagssize;
	}
	memset(t1->flags,0,flagssize * sizeof(opj_flag_t));

	t1->w=w;
	t1->h=h;

	return OPJ_TRUE;
}
void initWithPreallocatedStorage(int count, void* preallocStorage, int preallocCount) {
        SkASSERT(count >= 0);
        SkASSERT(preallocCount > 0);
        SkASSERT(preallocStorage);
        fCount = count;
        fMemArray = nullptr;
        fReserved = false;
        if (count > preallocCount) {
            fAllocCount = SkTMax(count, kMinHeapAllocCount);
            fMemArray = sk_malloc_throw(fAllocCount * sizeof(T));
            fOwnMemory = true;
        } else {
            fAllocCount = preallocCount;
            fMemArray = preallocStorage;
            fOwnMemory = false;
        }
    }
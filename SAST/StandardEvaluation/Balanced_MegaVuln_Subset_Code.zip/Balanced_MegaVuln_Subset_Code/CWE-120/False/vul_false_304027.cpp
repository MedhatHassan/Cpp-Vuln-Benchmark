static int mg_num_leap_years(int year) {
  return year / 4 - year / 100 + year / 400;
}
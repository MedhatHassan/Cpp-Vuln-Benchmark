static quic_hp_cipher *
quic_get_1rtt_hp_cipher(packet_info *pinfo, quic_info_data_t *quic_info, gboolean from_server)
{
    const char *error = NULL;

    /* Keys were previously not available. */
    if (quic_info->skip_decryption) {
        return NULL;
    }

    quic_pp_state_t *client_pp = &quic_info->client_pp;
    quic_pp_state_t *server_pp = &quic_info->server_pp;
    quic_pp_state_t *pp_state = !from_server ? client_pp : server_pp;

    /* Try to lookup secrets if not available. */
    if (!quic_info->client_pp.next_secret) {
        /* Query TLS for the cipher suite. */
        if (!tls_get_cipher_info(pinfo, 0, &quic_info->cipher_algo, &quic_info->cipher_mode, &quic_info->hash_algo)) {
            // No previous TLS handshake found or unsupported ciphers, fail.
            // This is an optimization that allows skipping checks for future
            // packets in case the capture starts in midst of a connection where
            // the handshake is not present.
            // If this breaks decryption because packets prior to the Server
            // Hello are somehow misdetected as Short Packet, then this
            // optimization should probably be removed.
            quic_info->skip_decryption = TRUE;
            return NULL;
        }

        /* Retrieve secrets for both the client and server. */
        if (!quic_get_traffic_secret(pinfo, quic_info->hash_algo, client_pp, TRUE) ||
            !quic_get_traffic_secret(pinfo, quic_info->hash_algo, server_pp, FALSE)) {
            quic_info->skip_decryption = TRUE;
            return NULL;
        }

        // Create initial cipher handles for Key Phase 0 using the 1-RTT keys.
        if (!quic_hp_cipher_prepare(&client_pp->hp_cipher, quic_info->hash_algo,
                                    quic_info->cipher_algo, client_pp->next_secret, &error) ||
            !quic_pp_cipher_prepare(&client_pp->pp_ciphers[0], quic_info->hash_algo,
                                    quic_info->cipher_algo, quic_info->cipher_mode, client_pp->next_secret, &error) ||
            !quic_hp_cipher_prepare(&server_pp->hp_cipher, quic_info->hash_algo,
                                    quic_info->cipher_algo, server_pp->next_secret, &error) ||
            !quic_pp_cipher_prepare(&server_pp->pp_ciphers[0], quic_info->hash_algo,
                                    quic_info->cipher_algo, quic_info->cipher_mode, server_pp->next_secret, &error)) {
            quic_info->skip_decryption = TRUE;
            return NULL;
        }
        // Rotate the 1-RTT key for the client and server for the next key update.
        quic_update_key(quic_info->version, quic_info->hash_algo, client_pp);
        quic_update_key(quic_info->version, quic_info->hash_algo, server_pp);

        // For efficiency, look up the application layer protocol once. The
        // handshake must have been completed before, so ALPN is known.
        const char *proto_name = tls_get_alpn(pinfo);
        if (proto_name) {
            quic_info->app_handle = dissector_get_string_handle(quic_proto_dissector_table, proto_name);
            // If no specific handle is found, alias "h3-*" to "h3" and "doq-*" to "doq"
            if (!quic_info->app_handle) {
                if (g_str_has_prefix(proto_name, "h3-")) {
                    quic_info->app_handle = dissector_get_string_handle(quic_proto_dissector_table, "h3");
                } else if (g_str_has_prefix(proto_name, "doq-")) {
                    quic_info->app_handle = dissector_get_string_handle(quic_proto_dissector_table, "doq");
                }
            }
        }
    }

    // Note: Header Protect cipher does not change after Key Update.
    return &pp_state->hp_cipher;
}
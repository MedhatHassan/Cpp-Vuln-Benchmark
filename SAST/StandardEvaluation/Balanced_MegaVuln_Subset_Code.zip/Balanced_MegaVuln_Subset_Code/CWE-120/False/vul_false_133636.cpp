static ecma_value_t
ecma_builtin_typedarray_prototype_at (ecma_typedarray_info_t *info_p, /**< object info */
                                      const ecma_value_t index) /**< index argument */
{
  ecma_length_t len = (ecma_length_t) info_p->length;
  ecma_length_t res_index;
  ecma_value_t return_value = ecma_builtin_helper_calculate_index (index, len, &res_index);

  if (return_value != ECMA_VALUE_EMPTY)
  {
    return return_value;
  }

  return ecma_get_typedarray_element (info_p, (ecma_number_t) res_index);
}
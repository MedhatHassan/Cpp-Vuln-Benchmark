static void gtkui_start_mitm(void)
{
   DEBUG_MSG("gtk_start_mitm");
   
   mitm_set(params);
   mitm_start();
}
static nxt_bool_t
njs_module_realpath_equal(const nxt_str_t *path1, const nxt_str_t *path2)
{
    char  rpath1[MAXPATHLEN], rpath2[MAXPATHLEN];

    realpath((char *) path1->start, rpath1);
    realpath((char *) path2->start, rpath2);

    return (strcmp(rpath1, rpath2) == 0);
}
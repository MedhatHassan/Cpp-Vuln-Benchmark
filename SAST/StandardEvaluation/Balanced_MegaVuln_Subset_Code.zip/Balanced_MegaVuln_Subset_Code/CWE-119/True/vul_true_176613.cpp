static bfd_boolean
ihex_scan (bfd *abfd)
{
  bfd_vma segbase;
  bfd_vma extbase;
  asection *sec;
  unsigned int lineno;
  bfd_boolean error;
  bfd_byte *buf = NULL;
  size_t bufsize;
  int c;

  if (bfd_seek (abfd, (file_ptr) 0, SEEK_SET) != 0)
    goto error_return;

  abfd->start_address = 0;

  segbase = 0;
  extbase = 0;
  sec = NULL;
  lineno = 1;
  error = FALSE;
  bufsize = 0;

  while ((c = ihex_get_byte (abfd, &error)) != EOF)
    {
      if (c == '\r')
	continue;
      else if (c == '\n')
	{
	  ++lineno;
	  continue;
	}
      else if (c != ':')
	{
	  ihex_bad_byte (abfd, lineno, c, error);
	  goto error_return;
	}
      else
	{
	  file_ptr pos;
	  char hdr[8];
	  unsigned int i;
	  unsigned int len;
	  bfd_vma addr;
	  unsigned int type;
	  unsigned int chars;
	  unsigned int chksum;

	  /* This is a data record.  */
	  pos = bfd_tell (abfd) - 1;

	  /* Read the header bytes.  */
	  if (bfd_bread (hdr, (bfd_size_type) 8, abfd) != 8)
	    goto error_return;

	  for (i = 0; i < 8; i++)
	    {
	      if (! ISHEX (hdr[i]))
		{
		  ihex_bad_byte (abfd, lineno, hdr[i], error);
		  goto error_return;
		}
	    }

	  len = HEX2 (hdr);
	  addr = HEX4 (hdr + 2);
	  type = HEX2 (hdr + 6);

	  /* Read the data bytes.  */
	  chars = len * 2 + 2;
	  if (chars >= bufsize)
	    {
	      buf = (bfd_byte *) bfd_realloc (buf, (bfd_size_type) chars);
	      if (buf == NULL)
		goto error_return;
	      bufsize = chars;
	    }

	  if (bfd_bread (buf, (bfd_size_type) chars, abfd) != chars)
	    goto error_return;

	  for (i = 0; i < chars; i++)
	    {
	      if (! ISHEX (buf[i]))
		{
		  ihex_bad_byte (abfd, lineno, buf[i], error);
		  goto error_return;
		}
	    }

	  /* Check the checksum.  */
	  chksum = len + addr + (addr >> 8) + type;
	  for (i = 0; i < len; i++)
	    chksum += HEX2 (buf + 2 * i);
	  if (((- chksum) & 0xff) != (unsigned int) HEX2 (buf + 2 * i))
	    {
	      (*_bfd_error_handler)
		(_("%B:%u: bad checksum in Intel Hex file (expected %u, found %u)"),
		 abfd, lineno,
		 (- chksum) & 0xff, (unsigned int) HEX2 (buf + 2 * i));
	      bfd_set_error (bfd_error_bad_value);
	      goto error_return;
	    }

	  switch (type)
	    {
	    case 0:
	      /* This is a data record.  */
	      if (sec != NULL
		  && sec->vma + sec->size == extbase + segbase + addr)
		{
		  /* This data goes at the end of the section we are
                     currently building.  */
		  sec->size += len;
		}
	      else if (len > 0)
		{
		  char secbuf[20];
		  char *secname;
		  bfd_size_type amt;
		  flagword flags;

		  sprintf (secbuf, ".sec%d", bfd_count_sections (abfd) + 1);
		  amt = strlen (secbuf) + 1;
		  secname = (char *) bfd_alloc (abfd, amt);
		  if (secname == NULL)
		    goto error_return;
		  strcpy (secname, secbuf);
		  flags = SEC_HAS_CONTENTS | SEC_LOAD | SEC_ALLOC;
		  sec = bfd_make_section_with_flags (abfd, secname, flags);
		  if (sec == NULL)
		    goto error_return;
		  sec->vma = extbase + segbase + addr;
		  sec->lma = extbase + segbase + addr;
		  sec->size = len;
		  sec->filepos = pos;
		}
	      break;

	    case 1:
	      /* An end record.  */
	      if (abfd->start_address == 0)
		abfd->start_address = addr;
	      if (buf != NULL)
		free (buf);
	      return TRUE;

	    case 2:
	      /* An extended address record.  */
	      if (len != 2)
		{
		  (*_bfd_error_handler)
		    (_("%B:%u: bad extended address record length in Intel Hex file"),
		     abfd, lineno);
		  bfd_set_error (bfd_error_bad_value);
		  goto error_return;
		}

	      segbase = HEX4 (buf) << 4;

	      sec = NULL;

	      break;

	    case 3:
	      /* An extended start address record.  */
	      if (len != 4)
		{
		  (*_bfd_error_handler)
		    (_("%B:%u: bad extended start address length in Intel Hex file"),
		     abfd, lineno);
		  bfd_set_error (bfd_error_bad_value);
		  goto error_return;
		}

	      abfd->start_address += (HEX4 (buf) << 4) + HEX4 (buf + 4);

	      sec = NULL;

	      break;

	    case 4:
	      /* An extended linear address record.  */
	      if (len != 2)
		{
		  (*_bfd_error_handler)
		    (_("%B:%u: bad extended linear address record length in Intel Hex file"),
		     abfd, lineno);
		  bfd_set_error (bfd_error_bad_value);
		  goto error_return;
		}

	      extbase = HEX4 (buf) << 16;

	      sec = NULL;

	      break;

	    case 5:
	      /* An extended linear start address record.  */
	      if (len != 2 && len != 4)
		{
		  (*_bfd_error_handler)
		    (_("%B:%u: bad extended linear start address length in Intel Hex file"),
		     abfd, lineno);
		  bfd_set_error (bfd_error_bad_value);
		  goto error_return;
		}

	      if (len == 2)
		abfd->start_address += HEX4 (buf) << 16;
	      else
		abfd->start_address = (HEX4 (buf) << 16) + HEX4 (buf + 4);

	      sec = NULL;

	      break;

	    default:
	      (*_bfd_error_handler)
		(_("%B:%u: unrecognized ihex type %u in Intel Hex file"),
		 abfd, lineno, type);
	      bfd_set_error (bfd_error_bad_value);
	      goto error_return;
	    }
	}
    }

  if (error)
    goto error_return;

  if (buf != NULL)
    free (buf);

  return TRUE;

 error_return:
  if (buf != NULL)
    free (buf);
  return FALSE;
}
int
lyd_list_has_keys(struct lyd_node *list)
{
    struct lyd_node *iter;
    struct lys_node_list *slist;
    int i;

    assert(list->schema->nodetype == LYS_LIST);

    /* even though hash is 0, it may be a valid hash, that is what we are going to check */

    slist = (struct lys_node_list *)list->schema;
    if (!slist->keys_size) {
        /* always has keys */
        return 1;
    }

    i = 0;
    iter = list->child;
    while (iter && (i < slist->keys_size)) {
        if (iter->schema != (struct lys_node *)slist->keys[i]) {
            /* missing key */
            return 0;
        }

        ++i;
        iter = iter->next;
    }
    if (i < slist->keys_size) {
        /* missing key */
        return 0;
    }

    /* all keys found */
    return 1;
}
struct SPECS *CloneSpecs(const struct SPECS *Q) {
    struct SPECS *P;
    struct COMMENT *x, *y;

    P = malloc(sizeof *P);
    if (P == NULL )
        bug("Out of memory.");
    memcpy(P, Q, sizeof(struct SPECS));
    P->stack_next = NULL;
    if (Q->comments != NULL )
        P->comments = malloc(sizeof *(P->comments));
    for (x = Q->comments, y = P->comments; x != NULL ;
            x = x->next, y = y->next) {
        memcpy(y, x, sizeof(struct COMMENT));
        y->start = my_strdup(x->start);
        y->end = my_strdup(x->end);
        if (x->next != NULL )
            y->next = malloc(sizeof *(y->next));
    }
    return P;
}
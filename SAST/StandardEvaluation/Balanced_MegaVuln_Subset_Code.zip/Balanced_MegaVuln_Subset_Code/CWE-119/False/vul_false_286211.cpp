static int dummy_task_setnice (struct task_struct *p, int nice)
{
	return 0;
}
static int dummy_socket_listen (struct socket *sock, int backlog)
{
	return 0;
}
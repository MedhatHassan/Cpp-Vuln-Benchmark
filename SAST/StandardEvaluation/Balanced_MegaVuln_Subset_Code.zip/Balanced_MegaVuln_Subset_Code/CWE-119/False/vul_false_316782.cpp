void VariableUnserializer::set(const char* buf, const char* end) {
  m_buf = buf;
  m_end = end;
}
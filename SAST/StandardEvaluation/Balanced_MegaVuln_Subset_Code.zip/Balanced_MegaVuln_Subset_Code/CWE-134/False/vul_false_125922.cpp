static void start_play_file_cmd_handler(int argc, char *argv[])
{
	const char *name;
	int fs;

	if (argc != 3) {
		output("Usage: start_play fs filename>\n");
		return;
	}

	fs = atoi(argv[1]);
	name = argv[2];

	/* Start File Playout */
	msystem_start_mic_file_playout(name, fs);
}
static gint
dissect_usb_hid_int_dynamic_value_variable(tvbuff_t *tvb, proto_tree *tree, hid_field_t *field,
        int bit_offset, int hf)
{
    gint32 val = 0;

    if (hid_unpack_logical(tvb, bit_offset, field->report_size, field->logical_min, &val))
        return -1;

    proto_tree_add_int_bits_format_value(tree, hf, tvb, bit_offset, field->report_size, val, ENC_LITTLE_ENDIAN, "%d", val);
    return 0;
}
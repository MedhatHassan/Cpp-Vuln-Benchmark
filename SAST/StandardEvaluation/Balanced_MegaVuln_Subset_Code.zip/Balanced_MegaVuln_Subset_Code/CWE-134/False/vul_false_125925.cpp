static bool video_key_handler(int ch)
{
	(void) ch;
	int new_state = conv_data.video_state;

	if (ch == 'V') {
		switch (conv_data.video_state) {
		case WCALL_VIDEO_STATE_STOPPED:
			new_state = WCALL_VIDEO_STATE_STARTED;
			break;
		default:
			new_state = WCALL_VIDEO_STATE_STOPPED;
			break;
		}
	}
	else if (ch == 'P') {
		switch (conv_data.video_state) {
		case WCALL_VIDEO_STATE_STARTED:
			new_state = WCALL_VIDEO_STATE_PAUSED;
			break;
		case WCALL_VIDEO_STATE_PAUSED:
			new_state = WCALL_VIDEO_STATE_STARTED;
			break;
		default:
			break;
		}
	}

	if (new_state != conv_data.video_state) {
		switch (new_state) {
		case WCALL_VIDEO_STATE_STARTED:
			vstart_cmd_handler(0, NULL);
			break;
		case WCALL_VIDEO_STATE_PAUSED:
			vpause_cmd_handler(0, NULL);
			break;
		case WCALL_VIDEO_STATE_STOPPED:
			vstop_cmd_handler(0, NULL);
			break;
		default:
			output("Unknown video state, doing nothing\n");
			break;
		}
	}

	return true;
}
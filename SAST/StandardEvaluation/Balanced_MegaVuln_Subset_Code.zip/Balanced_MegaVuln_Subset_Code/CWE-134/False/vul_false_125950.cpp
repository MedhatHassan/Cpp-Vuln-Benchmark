static void print_conv_list_entry(struct engine_conv *conv)
{
	if (conv == conv_data.curr)
		output("-> ");
	else
		output("   ");

	switch (conv->type) {
	case ENGINE_CONV_SELF:
		output("SL");
		break;
	case ENGINE_CONV_CONNECT:
		output("RQ");
		break;
	default:
		output("  ");
	}
	if (conv->unread)
		output("o ");
	else
		output("  ");

	output(" '%H'\n", engine_print_conv_name, conv);
}
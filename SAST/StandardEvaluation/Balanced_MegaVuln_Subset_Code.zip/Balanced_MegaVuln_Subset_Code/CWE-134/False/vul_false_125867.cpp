OSStatus audio_io_osx::play_process_impl(uint32_t inNumberFrames,
                                            const AudioTimeStamp *output_time_stamp,
                                            AudioBufferList *ioData) {
        
        int n_channels = 1;
        
        uint32_t tmp_play_latency_ms = get_play_latency(output_time_stamp);
        
        int32_t diff = (int32_t)tmp_play_latency_ms - (int32_t)prev_play_latency_ms_;
        if( diff > DELAY_JUMP_FOR_RESET_MS ){
            /* Sudden Jump in latency - AEC will have problems */
            play_delay_warning_ = 1;
        }
        
        prev_play_latency_ms_ = tmp_play_latency_ms;
        
        play_latency_ms_ = tmp_play_latency_ms;
        
        int16_t* data;
        unsigned int dataSizeBytes;
        if(ioData->mNumberBuffers == 1){
            data = static_cast<int16_t*>(ioData->mBuffers[0].mData); // 0 is left 1 is right channel
            dataSizeBytes = ioData->mBuffers[0].mDataByteSize;
        } else {
            data = static_cast<int16_t*>(ioData->mBuffers[1].mData); // 0 is left 1 is right channel
            dataSizeBytes = ioData->mBuffers[1].mDataByteSize;
        }
        unsigned int dataSize = dataSizeBytes/2;  // Number of samples
        
        if(dataSize == 2*inNumberFrames){
            n_channels = 2;
            dataSize = inNumberFrames;
        }
        
        if (dataSize != inNumberFrames) {  // Should always be the same
            warning("audio_io_osx: dataSize (%u) != inNumberFrames (%u)",
                         dataSize, (unsigned int)inNumberFrames);
        }
        memset(data, 0, dataSizeBytes);  // Start with empty buffer
        
        if (is_playing_) {
            unsigned int noSamp10ms = play_fs_hz_ / 100;
            int16_t dataTmp[noSamp10ms*2];
            unsigned int dataPos = 0;
            uint32_t noSamplesOut = 0;
            unsigned int nCopy = 0;
            
            // First insert data from playout buffer if any
            if (play_buffer_used_ > 0) {
                nCopy = (dataSize < play_buffer_used_) ?
                dataSize : play_buffer_used_;
                if (nCopy != play_buffer_used_) {
                    warning("audio_io_osx: nCopy (%u) != play_buffer_used_ (%u) \n",
                                 nCopy, play_buffer_used_);
                }
                
                // Should never end here as Callback asks for 10 ms which is ACM's frame size
                debug("audio_io_osx: playout not asking for 10 ms ? \n");
                
                memcpy(data, play_buffer_, nCopy * n_channels * sizeof(int16_t));
                dataPos = nCopy;
                memset(play_buffer_, 0, sizeof(play_buffer_));
                play_buffer_used_ = 0;
            }
            
            // Now get the rest from Audio Device Buffer
            while (dataPos < dataSize) {
                // Update playout delay
                update_play_delay();
                
                if(audioCallback_){
                    int64_t elapsed_time_ms, ntp_time_ms;
                    
                    int32_t ret = audioCallback_->NeedMorePlayData(noSamp10ms, 2, n_channels, play_fs_hz_,
                                                                   (void*)dataTmp, noSamplesOut,
                                                                   &elapsed_time_ms, &ntp_time_ms);
                }
                
                // Cast OK since only equality comparison
                if (noSamp10ms != (unsigned int)noSamplesOut) {
                    // Should never happen
                    warning("audio_io_osx: noSamp10ms (%u) != noSamplesOut (%d)",
                                 noSamp10ms, noSamplesOut);
                }
                
                // Insert as much as fits in data buffer
                nCopy = (dataSize-dataPos) > noSamp10ms ?
                noSamp10ms : (dataSize-dataPos);
                
                 memcpy(data, dataTmp, nCopy * n_channels * sizeof(int16_t));

                // Save rest in playout buffer if any
                if (nCopy < noSamp10ms) {
                    memcpy( play_buffer_, &dataTmp[nCopy], sizeof(int16_t)*(noSamp10ms-nCopy));
                    play_buffer_used_ = noSamp10ms - nCopy;
                }
                
                // Update loop/index counter, if we copied less than noSamp10ms
                // samples we shall quit loop anyway
                dataPos += noSamp10ms;
            }
        }
        //_numRenderCalls+=1;
        
        return 0;
    }
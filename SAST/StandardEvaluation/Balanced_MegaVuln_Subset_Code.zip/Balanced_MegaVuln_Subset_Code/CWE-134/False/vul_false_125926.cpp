static bool calling3_key_handler(int ch)
{
	(void) ch;

	calling3_dump();

	return true;
}
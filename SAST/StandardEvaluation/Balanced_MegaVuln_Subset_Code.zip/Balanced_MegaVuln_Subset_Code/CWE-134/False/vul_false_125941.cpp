static bool list_key_handler(int ch)
{
	struct le *le;

	(void) ch;

	output("Conversation list");
	if (conv_data.archived)
		output(" with archive");
	output(" (%u entries)", list_count(&conv_data.convl));
	output(":\n");
	LIST_FOREACH(&conv_data.convl, le) {
		struct engine_conv *conv = le->data;

		if (conv->archived && !conv_data.archived)
			continue;

		print_conv_list_entry(conv);
	}
	output("EOL\n");

	return true;
}
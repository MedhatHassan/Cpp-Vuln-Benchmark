static bool info_key_handler(int ch)
{
	struct le *le;
	struct wcall_members *members = NULL;
	size_t p;

	(void) ch;

	if (!conv_data.curr)
		return true;

	output("%H\n", engine_print_conv_name, conv_data.curr);
	output("ID:   %s\n", conv_data.curr->id);
	output("Type: ");
	switch (conv_data.curr->type) {
	case ENGINE_CONV_REGULAR:
		output("group conversation\n");
		break;
	case ENGINE_CONV_SELF:
		output("selfconversation\n");
		break;
	case ENGINE_CONV_ONE:
		output("one-on-one conversation\n");
		break;
	case ENGINE_CONV_CONNECT:
		output("connect request pending\n");
		break;
	default:
		output("unknown\n");
	}
	output("Members:\n");
	LIST_FOREACH(&conv_data.curr->memberl, le) {
		struct engine_conv_member *mbr = le->data;

		output("  %s %s", mbr->user->id,
			mbr->user->display_name);
		if (!mbr->active)
			output(" [left]");
		if (conv_data.curr->type == ENGINE_CONV_REGULAR) {
			members = wcall_get_members(calling3_get_wuser(), conv_data.curr->id);
			if (members) {
				for (p = 0; p < members->membc; p++) {
					if (strcmp(members->membv[p].userid, mbr->user->id) == 0) {
						output(" [in call]");
						break;
					}
				}
				wcall_free_members(members);
			}
		}

		output("\n");
	}
	if (!conv_data.curr->active)
		output("You have left the conversation.\n");
	if (conv_data.curr->archived)
		output("You have archived the conversation.\n");
	if (conv_data.curr->muted)
		output("You have muted the conversation.\n");
	output("Call state: ");

	output("%s\n", wcall_state_name(wcall_get_state(calling3_get_wuser(), conv_data.curr->id)));

	output("Last event: %s\n", conv_data.curr->last_event);
	output("Last read:  %s\n", conv_data.curr->last_read);

	return true;
}
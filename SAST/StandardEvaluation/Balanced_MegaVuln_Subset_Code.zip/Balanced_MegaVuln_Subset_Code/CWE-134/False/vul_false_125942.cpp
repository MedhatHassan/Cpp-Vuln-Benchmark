static void vstart_cmd_handler(int argc, char *argv[])
{
	if (WCALL_VIDEO_STATE_STARTED != conv_data.video_state) {
		output("Enabling preview, send state STARTED\n");
		preview_start();
		conv_data.video_state = WCALL_VIDEO_STATE_STARTED;
		calling3_set_video_send_state(conv_data.curr, conv_data.video_state);
	}
}
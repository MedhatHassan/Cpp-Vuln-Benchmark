static void
dissect_hid_variable(tvbuff_t* tvb, packet_info _U_* pinfo, proto_tree* tree, hid_field_t* field,
                     guint32 usage, int bit_offset)
{
    gint ret = 0;

    /* vendor data (0xff00 - 0xffff) */
    if ((USAGE_PAGE(usage) & 0xff00) == 0xff00) {
        proto_tree_add_bits_item(tree, hf_usbhid_vendor_data, tvb, bit_offset, field->report_size, ENC_LITTLE_ENDIAN);
        return;
    }

    switch (USAGE_PAGE(usage))
    {
    case GENERIC_DESKTOP_CONTROLS_PAGE:
        ret = dissect_usb_hid_generic_desktop_controls_page(tvb, pinfo, tree, field, usage, bit_offset);
        break;

    case KEYBOARD_KEYPAD_PAGE:
        ret = dissect_usb_hid_keyboard_page(tvb, pinfo, tree, field, usage, bit_offset);
        break;

    case BUTTON_PAGE:
        ret = dissect_usb_hid_button_page(tvb, pinfo, tree, field, usage, bit_offset);
        break;

    default:
        ret = -1;
        break;
    }

    if (ret) {
        guint32 val = 0;
        proto_item *ti =
            proto_tree_add_uint_bits_format_value(tree, hf_usb_hid_localitem_usage, tvb, bit_offset, field->report_size,
                                                  usage, ENC_LITTLE_ENDIAN, "%s", get_usage_page_item_string(pinfo->pool, USAGE_PAGE(usage), USAGE_ID(usage)));
        if (0 == hid_unpack_logical(tvb, bit_offset, field->report_size, field->logical_min, &val))
            proto_item_append_text(ti, ": %d", val);
    }
}
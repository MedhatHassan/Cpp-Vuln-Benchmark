static void batch_call_handler(void *arg)
{
	struct batch_call *bcall;
	bool incall = false;
	int state;

	state = wcall_get_state(calling3_get_wuser(), conv_data.curr->id);

	switch (state) {

	case WCALL_STATE_NONE:
	case WCALL_STATE_UNKNOWN:
		incall = false;
		break;

	default:
		incall = true;
		break;
	}

	if (incall) {
		if (conv_data.batch_retry++ >= MAX_BATCH_RETRIES) {
			output("batch_call: max reties reached, aborting\n");
			return;
		}
		else {
			uint32_t delay = conv_data.batch_retry;
			output("batch_call: still in a call, waiting %us\n", delay);
			tmr_start(&conv_data.tmr_batch, delay*1000, batch_call_handler, 0);
			return;
		}
	}
	conv_data.batch_retry = 0;

	bcall = &conv_data.batchv[conv_data.batchi];

	bcall->call_num = conv_data.batchi + 1;
	bcall->started = true;
	bcall->ts_start = tmr_jiffies();

	output("batch_call: starting call number %zu\n", bcall->call_num);
	call_key_handler(0);
}
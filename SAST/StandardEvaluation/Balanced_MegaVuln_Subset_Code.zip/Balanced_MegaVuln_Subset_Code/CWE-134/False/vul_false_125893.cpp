static void use_audio_effect_cmd_handler(int argc, char *argv[])
{
    int err = 0;
    (void) argc;
    
    if (!conv_data.curr) {
        output("No conversation selected ...\n");
        return;
    }
    
    if (argc != 2) {
        output("usage: useAudioEffect effect 0 - 7 \n");
        return;
    }
    
    enum audio_effect effect;
    if(atoi(argv[1]) == 7){
        effect = AUDIO_EFFECT_HARMONIZER_MED;
    } else if(atoi(argv[1]) == 6){
        effect = AUDIO_EFFECT_VOCODER_MIN;
    } else if(atoi(argv[1]) == 5){
        effect = AUDIO_EFFECT_AUTO_TUNE_MED;
    } else if(atoi(argv[1]) == 4){
        effect = AUDIO_EFFECT_PITCH_UP_DOWN_MED;
    } else if(atoi(argv[1]) == 3){
        effect = AUDIO_EFFECT_CHORUS_MED;
    } else if(atoi(argv[1]) == 2){
        effect = AUDIO_EFFECT_PITCH_DOWN_SHIFT_MAX;
    } else if(atoi(argv[1]) == 1){
        effect = AUDIO_EFFECT_PITCH_UP_SHIFT_MAX;
    } else {
        effect = AUDIO_EFFECT_NONE;
    }

#if USE_AVSLIB
    err = voe_set_audio_effect(effect);
#endif
    
    if (err)
	    output("Failed: %m.\n", err);
    else
	    output("OK\n");
}
int32_t audio_io_osx::StopPlayout() {
        pthread_mutex_lock(&mutex_);
        
        if (!play_is_initialized_) {
            info("audio_io_osx: Recording is not initialized \n");
            goto out;
        }
        
        is_playing_ = false;
        
        if (!is_recording_) {
            // Both playout and recording has stopped, shutdown the device
            shutdown_audio_unit();
        }
        
        play_is_initialized_ = false;
        
    out:
        pthread_mutex_unlock(&mutex_);
        return 0;
	}
CbrDetectorRemote::Result CbrDetectorRemote::Decrypt(cricket::MediaType media_type,
						const std::vector<uint32_t>& csrcs,
						rtc::ArrayView<const uint8_t> additional_data,
						rtc::ArrayView<const uint8_t> encrypted_frame,
						rtc::ArrayView<uint8_t> frame)
{
	const uint8_t *src = encrypted_frame.data();
	uint8_t *dst = frame.data();
	uint32_t data_len = encrypted_frame.size();

	if (media_type == cricket::MEDIA_TYPE_AUDIO) {
		if (data_len == frame_size && frame_size >= 40) {
			frame_count++;
			if (frame_count > 200 && !detected) {
				info("CBR detector: remote cbr detected\n");
				detected = true;
			}
		}
		else {
			frame_count = 0;
			frame_size = data_len;
			if (detected) {
				info("CBR detector: remote cbr detected disabled\n");
				detected = false;
			}
		}

	}

	memcpy(dst, src, data_len);

out:
	return CbrDetectorRemote::Result(CbrDetectorRemote::Status::kOk, data_len);
}
void hexdump(msg_info msg_info, const char *mem, unsigned int len)
{
    unsigned int i, j;
    char str[10 + HEXDUMP_COLS * 4 + 2];
    int c = 0; /* index in str */

    for(i = 0; i < len + ((len % HEXDUMP_COLS) ? (HEXDUMP_COLS - len % HEXDUMP_COLS) : 0); i++)
    {
        /* print offset */
        if(i % HEXDUMP_COLS == 0)
            c += sprintf(&str[c], "0x%06x: ", i);

        /* print hex data */
        if(i < len)
            c += sprintf(&str[c], "%02x ", 0xFF & mem[i]);
        else /* end of block, just aligning for ASCII dump */
            c+= sprintf(&str[c], "   ");

        /* print ASCII dump */
        if(i % HEXDUMP_COLS == (HEXDUMP_COLS - 1)) {
            for(j = i - (HEXDUMP_COLS - 1); j <= i; j++) {
                if(j >= len) /* end of block, not really printing */
                    str[c++] = ' ';
                else if(isprint(mem[j])) /* printable char */
                    str[c++] = 0xFF & mem[j];
                else /* other char */
                    str[c++] = '.';
            }
            str[c++] = '\n';
            str[c++] = 0;
            print_message(msg_info, str);
            c = 0;
        }
    }
}
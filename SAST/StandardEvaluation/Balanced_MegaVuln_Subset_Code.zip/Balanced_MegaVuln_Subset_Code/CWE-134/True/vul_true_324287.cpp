static gchar*
get_usage_page_item_string(wmem_allocator_t *pool, guint32 usage_page, guint32 id)
{
    const char *str = NULL;

    switch (usage_page)
    {
    case GENERIC_DESKTOP_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_generic_desktop_controls_usage_page_vals);
        break;
    case SIMULATION_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_simulation_control_usage_page_vals);
        break;
    case VR_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_vr_controls_usage_page_vals);
        break;
    case SPORT_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_sport_controls_usage_page_vals);
        break;
    case GAME_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_game_controls_usage_page_vals);
        break;
    case GENERIC_DEVICE_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_generic_device_controls_usage_page_vals);
        break;
    case KEYBOARD_KEYPAD_PAGE:
        str = try_val_to_str(id, usb_hid_keyboard_keypad_usage_page_vals);
        break;
    case LED_PAGE:
        str = try_val_to_str(id, usb_hid_led_usage_page_vals);
        break;
    case BUTTON_PAGE:
        str = try_val_to_str(id, usb_hid_button_usage_page_vals);
        if (!str)
            str = "Button %u";
        break;
    case ORDINAL_PAGE:
        str = try_val_to_str(id, usb_hid_ordinal_usage_page_vals);
        break;
    case TELEPHONY_PAGE:
        str = try_val_to_str(id, usb_hid_telephony_device_usage_page_vals);
        break;
    case CONSUMER_PAGE:
        str = try_val_to_str(id, usb_hid_consumer_usage_page_vals);
        if (!str)
            str = "Instance %u";
        break;
    case DIGITIZER_PAGE:
        str = try_val_to_str(id, usb_hid_digitizers_usage_page_vals);
        break;
    case HAPTICS_PAGE:
        str = try_val_to_str(id, usb_hid_haptic_usage_page_vals);
        if (id >= 0x2001 && id <= 0x2FFF)
            str = "Vendor Waveforms";
        break;
    case PID_PAGE:
        str = try_val_to_str(id, usb_hid_physical_input_device_usage_page_vals);
        break;
    case UNICODE_PAGE:
        str = "Character U+%04X";
        break;
    case EYE_AND_HEAD_TRACKER_PAGE:
        str = try_val_to_str(id, usb_hid_eye_and_head_tracker_usage_page_vals);
        break;
    case ALPHANUMERIC_DISPLAY_PAGE:
        str = try_val_to_str(id, usb_hid_alphanumeric_display_usage_page_vals);
        break;
    case SENSOR_PAGE:
        str = try_val_to_str(id, usb_hid_sensor_usage_page_vals);
        if (!str)
            str = try_rval_to_str(id, usb_hid_sensor_usage_page_ranges);
        break;
    case MEDICAL_INSTRUMENTS_PAGE:
        str = try_val_to_str(id, usb_hid_medical_instrument_usage_page_vals);
        break;
    case BRAILLE_DISPLAY_PAGE:
        str = try_val_to_str(id, usb_hid_braille_dispaly_usage_page_vals);
        break;
    case LIGHTING_AND_ILLUMINATION_PAGE:
        str = try_val_to_str(id, usb_hid_lighting_and_illumination_usage_page_vals);
        break;
    case USB_MONITOR_PAGE:
        str = try_val_to_str(id, usb_hid_monitor_usage_page_vals);
        break;
    case USB_ENUMERATED_VALUES_PAGE:
        str = "ENUM_%u";
        break;
    case VESA_VIRTUAL_CONTROLS_PAGE:
        str = try_val_to_str(id, usb_hid_vesa_virtual_control_usage_page_vals);
        break;
    case POWER_DEVICE_PAGE:
        str = try_val_to_str(id, usb_hid_power_device_usage_page_vals);
        break;
    case BATTERY_SYSTEM_PAGE:
        str = try_val_to_str(id, usb_hid_battery_system_usage_page_vals);
        break;
    case BARCODE_SCANNER_PAGE:
        str = try_val_to_str(id, usb_hid_barcode_scanner_usage_page_vals);
        break;
    case WEIGHING_PAGE:
        str = try_val_to_str(id, usb_hid_weighing_devices_usage_page_vals);
        break;
    case MSR_PAGE:
        str = try_val_to_str(id, usb_hid_magnetic_stripe_reader_usage_page_vals);
        break;
    case CAMERA_CONTROL_PAGE:
        str = try_val_to_str(id, usb_hid_camera_control_usage_page_vals);
        break;
    case ARCADE_PAGE:
        str = try_val_to_str(id, usb_hid_arcade_usage_page_vals);
        break;
    case FIDO_ALLIANCE_PAGE:
        str = try_val_to_str(id, usb_hid_fido_alliance_usage_page_vals);
        break;
    default:
        if ((usage_page & VENDOR_PAGE_HBYTE) == VENDOR_PAGE_HBYTE)
            str = "Vendor";
        break;
    }

    if (!str)
        str = "Reserved";

    return wmem_strdup_printf(pool, str, id);
}
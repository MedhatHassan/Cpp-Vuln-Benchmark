int32_t audio_io_osx::shutdown_audio_unit() {
        // Close and delete AU
        OSStatus result = -1;
        if (NULL != au_rec_) {
            result = AudioOutputUnitStop(au_rec_);
            if (0 != result) {
                error("audio_io_osx: Error stopping Audio Unit (result=%d) \n", result);
            }
            result = AudioComponentInstanceDispose(au_rec_);
            if (0 != result) {
                error("audio_io_osx: Error disposing Audio Unit (result=%d) \n", result);
            }
            au_rec_ = NULL;
        }
        if (NULL != au_play_) {
            result = AudioOutputUnitStop(au_play_);
            if (0 != result) {
                error("audio_io_osx: Error stopping Audio Unit (result=%d) \n", result);
            }
            result = AudioComponentInstanceDispose(au_play_);
            if (0 != result) {
                error("audio_io_osx: Error disposing Audio Unit (result=%d) \n", result);
            }
            au_play_ = NULL;
        }
        return 0;
    }